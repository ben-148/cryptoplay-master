class CustomError {
  msg;
  constructor(errMsg) {
    this.msg = errMsg;
  }
}

module.exports = CustomError;
